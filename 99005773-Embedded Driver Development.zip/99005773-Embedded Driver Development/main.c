#include "stm32f407xx_gpio_driver.h"
void delay(void)
{
	for(uint32_t i=0;i<50000000;i++);
}
int main(void)
{
	GPIO_Handle_t GpioLed;
	GpioLed.pGPIOX=GPIOD;
	GpioLed.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_15;
	GpioLed.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUT;
	GpioLed.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_MED;
	GpioLed.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioLed.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PUPD;

	GPIO_Handle_t GpioL;
	GpioL.pGPIOX=GPIOD;
	GpioL.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_13;
	GpioL.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUT;
	GpioL.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_MED;
	GpioL.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioL.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PUPD;

	GPIO_Handle_t GpioE;
	GpioE.pGPIOX=GPIOD;
	GpioE.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_13;
	GpioE.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUT;
	GpioE.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_MED;
	GpioE.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioE.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PUPD;

	GPIO_Handle_t GpioLe;
	GpioLe.pGPIOX=GPIOD;
	GpioLe.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_13;
	GpioLe.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUT;
	GpioLe.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_MED;
	GpioLe.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioLe.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PUPD;

	GPIO_PeriClockControl(GPIOD, ENABLE);
	GPIO_PeriClockControl(GPIOD, ENABLE);
	GPIO_PeriClockControl(GPIOD, ENABLE);
	GPIO_Init(&GpioLed);
	GPIO_Init(&GpioL);
	GPIO_Init(&GpioLe);
	GPIO_Init(&GpioE);

	while(1)
	{
		GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_12);
		GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_13);
		GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_14);
		GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_15);
		delay();

	}
	return 0;
}
